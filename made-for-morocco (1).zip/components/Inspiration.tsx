import React, { useState, useRef } from 'react';
import { ArrowLeft, ArrowRight } from 'lucide-react';

const categories = [
  {
    title: "Romance",
    description: "From seaside escapes to desert adventures and mountain retreats, Morocco offers something for every mood. It’s the perfect destination for your wedding, honeymoon, anniversary or “just because” couples trip. However you chose to spend your travels, Morocco is sure to make for an unforgettable journey to bring you and your partner closer than ever.",
    image: "https://images.unsplash.com/photo-1532279248814-7683684d7184?q=80&w=510&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
  },
  {
    title: "Gastronomy",
    description: "Morocco is a feast for the senses, and nowhere is this more evident than in its cuisine. Join a master chef in Fes for a market tour, learn the secrets of the perfect tagine, and dine under the stars. Every meal is a story of spices, traditions, and hospitality passed down through generations.",
    image: "https://images.pexels.com/photos/4502972/pexels-photo-4502972.jpeg"
  },
  {
    title: "Adventure",
    description: "For those who seek the thrill of the unknown, the Kingdom delivers. Traverse the High Atlas peaks, windsurf in Essaouira, or embark on a multi-day trek across the Sahara dunes. Experience the raw, untamed beauty of the landscape with the comfort of bespoke luxury guides.",
    image: "https://www.igomorocco.com/wp-content/uploads/2025/02/Trekking-Atlas-Mountains.webp"
  },
  {
    title: "Wellness",
    description: "Rejuvenate your spirit in the land of Argan. Our wellness journeys center around traditional Hammams, holistic spa treatments using indigenous ingredients, and yoga retreats in serene kasbahs. It is a restoration of balance in the most beautiful of settings.",
    image: "https://images.pexels.com/photos/3889843/pexels-photo-3889843.jpeg"
  }
];

export const Inspiration: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  
  // Use Refs for gesture tracking to avoid re-renders during drag
  const touchStartX = useRef<number | null>(null);
  const touchEndX = useRef<number | null>(null);

  const next = () => {
    setCurrentIndex((prev) => (prev + 1) % categories.length);
  };

  const prev = () => {
    setCurrentIndex((prev) => (prev - 1 + categories.length) % categories.length);
  };

  // Unified Gesture Logic
  const handleStart = (clientX: number) => {
    touchStartX.current = clientX;
    touchEndX.current = null; // Reset end on new start
  };

  const handleMove = (clientX: number) => {
    touchEndX.current = clientX;
  };

  const handleEnd = () => {
    if (!touchStartX.current || !touchEndX.current) return;
    
    const distance = touchStartX.current - touchEndX.current;
    const isLeftSwipe = distance > 50; // Dragged left -> Next
    const isRightSwipe = distance < -50; // Dragged right -> Prev
    
    if (isLeftSwipe) next();
    if (isRightSwipe) prev();
    
    // Reset
    touchStartX.current = null;
    touchEndX.current = null;
  };

  // Touch Handlers
  const onTouchStart = (e: React.TouchEvent) => handleStart(e.targetTouches[0].clientX);
  const onTouchMove = (e: React.TouchEvent) => handleMove(e.targetTouches[0].clientX);
  const onTouchEnd = () => handleEnd();

  // Mouse Handlers (for desktop dragging)
  const onMouseDown = (e: React.MouseEvent) => handleStart(e.clientX);
  const onMouseMove = (e: React.MouseEvent) => {
    // Only track move if mouse is down (start exists)
    if (touchStartX.current !== null) {
      handleMove(e.clientX);
    }
  };
  const onMouseUp = () => handleEnd();
  const onMouseLeave = () => {
    if (touchStartX.current !== null) handleEnd();
  };

  return (
    <section className="py-16 md:py-24 bg-cream relative overflow-hidden select-none">
      <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-y-8 lg:gap-20 items-center">
        
        {/* Header Area (Mobile: Top, Desktop: Right Top) */}
        <div className="text-center lg:text-right space-y-4 lg:col-start-2 lg:row-start-1 self-end">
            <h4 className="text-terracotta font-display tracking-[0.3em] text-xs md:text-sm font-bold uppercase">
               GET INSPIRED
            </h4>
            <h2 key={currentIndex} className="text-5xl md:text-7xl font-display text-terracotta animate-fade-in-up">
               {categories[currentIndex].title}
            </h2>
        </div>

        {/* Visual Stack (Mobile: Middle, Desktop: Left Span 2 Rows) */}
        <div 
           className="relative h-[320px] md:h-[500px] w-full flex items-center justify-center [perspective:1000px] lg:row-span-2 lg:col-start-1 lg:row-start-1 cursor-grab active:cursor-grabbing touch-pan-y"
           onTouchStart={onTouchStart}
           onTouchMove={onTouchMove}
           onTouchEnd={onTouchEnd}
           onMouseDown={onMouseDown}
           onMouseMove={onMouseMove}
           onMouseUp={onMouseUp}
           onMouseLeave={onMouseLeave}
        >
             {/* Decorative 'Back' Card - Left */}
             <div className="absolute w-[220px] md:w-[350px] h-[300px] md:h-[450px] bg-white p-2 shadow-xl rounded-sm transform -rotate-3 md:-rotate-6 -translate-x-3 md:-translate-x-12 opacity-80 transition-all duration-500 border border-gold/20">
                <img 
                   src={categories[(currentIndex + 2) % categories.length].image} 
                   className="w-full h-full object-cover filter grayscale opacity-50 select-none pointer-events-none" 
                   alt="decoration"
                />
             </div>
             
             {/* Decorative 'Back' Card - Right */}
             <div className="absolute w-[220px] md:w-[350px] h-[300px] md:h-[450px] bg-white p-2 shadow-xl rounded-sm transform rotate-3 md:rotate-6 translate-x-3 md:translate-x-12 opacity-80 transition-all duration-500 border border-gold/20">
                 <img 
                   src={categories[(currentIndex + 1) % categories.length].image} 
                   className="w-full h-full object-cover filter grayscale opacity-50 select-none pointer-events-none" 
                   alt="decoration"
                />
             </div>
             
             {/* Main Active Card */}
             <div className="absolute w-[220px] md:w-[350px] h-[320px] md:h-[480px] bg-white p-3 shadow-2xl rounded-sm z-20 transform transition-all duration-700 hover:scale-[1.02] md:hover:scale-105">
                <div className="w-full h-full relative overflow-hidden">
                   <img 
                      key={currentIndex}
                      src={categories[currentIndex].image} 
                      alt={categories[currentIndex].title}
                      className="w-full h-full object-cover animate-fade-in select-none pointer-events-none"
                      draggable="false"
                   />
                   <div className="absolute inset-0 border border-gold/20 pointer-events-none"></div>
                </div>
             </div>
             
             {/* Swipe Hint (Mobile Only) */}
             <div className="lg:hidden absolute bottom-0 text-gold/50 text-[10px] tracking-widest uppercase animate-pulse pointer-events-none">
                Swipe to browse
             </div>
        </div>

        {/* Body Area (Mobile: Bottom, Desktop: Right Bottom) */}
        <div className="text-center lg:text-right space-y-6 lg:ml-auto max-w-xl lg:col-start-2 lg:row-start-2 self-start">
            <p key={currentIndex + '-desc'} className="font-serif text-indigo/70 text-base md:text-lg leading-relaxed animate-fade-in delay-100 px-4 md:px-0">
               {categories[currentIndex].description}
            </p>

            {/* Controls */}
            <div className="flex justify-center lg:justify-end gap-6 pt-2 md:pt-8">
               <button 
                 onClick={prev}
                 className="w-12 h-10 md:w-16 md:h-12 rounded-full border border-indigo/30 text-indigo flex items-center justify-center hover:bg-indigo hover:text-gold transition-all duration-300"
               >
                  <ArrowLeft size={18} className="md:w-5 md:h-5" strokeWidth={1} />
               </button>
               <button 
                 onClick={next}
                 className="w-12 h-10 md:w-16 md:h-12 rounded-full border border-indigo/30 text-indigo flex items-center justify-center hover:bg-indigo hover:text-gold transition-all duration-300"
               >
                  <ArrowRight size={18} className="md:w-5 md:h-5" strokeWidth={1} />
               </button>
            </div>
        </div>

      </div>
    </section>
  );
};