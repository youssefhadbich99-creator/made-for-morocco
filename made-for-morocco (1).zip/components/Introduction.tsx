import React from 'react';
import { Compass } from 'lucide-react';

export const Introduction: React.FC = () => {
  return (
    <section className="relative py-32 bg-cream overflow-hidden flex items-center justify-center">
      
      {/* Abstract Moroccan Line Map Background */}
      <div className="absolute inset-0 flex items-center justify-center opacity-10 pointer-events-none select-none">
         <svg 
            viewBox="0 0 500 600" 
            className="w-full h-[140%] md:h-[180%] stroke-gold fill-none"
            style={{ strokeWidth: 1.5, strokeLinecap: 'round', strokeLinejoin: 'round' }}
         >
            {/* Stylized Morocco Outline */}
            <path d="M180,50 
                     C200,45 240,40 280,55 
                     C300,60 320,65 330,80
                     C340,100 350,150 340,200
                     C330,250 300,400 280,480
                     C260,520 200,550 150,520
                     C120,500 100,450 110,400
                     C120,350 140,200 130,150
                     C120,100 150,60 180,50 Z" 
            />
            
            {/* Internal "Journey" Lines (Decorative) */}
            <path d="M280,55 Q250,150 200,250 T280,450" strokeDasharray="4 6" className="opacity-50" />
            
            {/* City Markers */}
            <circle cx="280" cy="55" r="3" className="fill-gold" /> {/* Tangier approx */}
            <circle cx="200" cy="250" r="3" className="fill-gold" /> {/* Marrakech approx */}
            <circle cx="250" cy="150" r="3" className="fill-gold" /> {/* Fes approx */}
            <circle cx="280" cy="450" r="3" className="fill-gold" /> {/* Sahara approx */}
         </svg>
      </div>

      <div className="max-w-4xl mx-auto px-6 relative z-10 text-center space-y-8">
         <div className="flex justify-center mb-6">
            <Compass size={32} strokeWidth={1} className="text-gold animate-spin-slow" />
         </div>

         <h2 className="text-sm font-display tracking-[0.3em] text-terracotta uppercase">
            The Atelier of Travel
         </h2>
         
         <h1 className="text-4xl md:text-5xl font-serif text-indigo italic leading-tight">
           "We do not strictly follow maps;<br/>
           we follow the <span className="border-b border-gold pb-1">rhythm</span> of the land."
         </h1>

         <p className="font-sans text-indigo/70 text-lg leading-relaxed max-w-2xl mx-auto">
           Made For Morocco is not merely an agency, but a curator of moments. 
           We bridge the gap between the observer and the observed, opening doors that 
           remain closed to the ordinary traveler. From private dinners in the Agafay dunes 
           to tea with artisans in Fes, your story is waiting to be written.
         </p>

         <div className="pt-8">
            <img 
              src="https://upload.wikimedia.org/wikipedia/commons/thumb/6/6b/Tifinagh_az.svg/1200px-Tifinagh_az.svg.png" 
              alt="Amazigh Symbol" 
              className="h-8 w-auto mx-auto opacity-20"
            />
         </div>
      </div>
    </section>
  );
};