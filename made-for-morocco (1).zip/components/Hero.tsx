import React, { useState, useEffect } from 'react';
import { ArrowDown } from 'lucide-react';

const slides = [
  {
    image: "https://images.unsplash.com/photo-1564507004663-b6dfb3c824d5?q=80&w=774&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
    quote: "A tapestry of colors and senses.",
    alt: "Moroccan Architecture"
  },
  {
    image: "https://images.unsplash.com/photo-1580820940344-ef6a03a3147b?q=80&w=331&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
    quote: "Where silence speaks to the soul.",
    alt: "Sahara Desert"
  },
  {
    image: "https://images.unsplash.com/photo-1628642004970-1da51c8c7dec?q=80&w=639&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
    quote: "A sanctuary behind ancient walls.",
    alt: "Authentic Riad"
  },
  {
    image: "https://images.unsplash.com/photo-1542366172-ffed3bebb7db?q=80&w=386&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
    quote: "Handcrafted legacies woven into time.",
    alt: "Traditional Leather Makers in Fes"
  }
];

export const Hero: React.FC = () => {
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section className="relative min-h-screen flex items-center justify-center pt-32 pb-20 overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 bg-pattern-subtle opacity-10 pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-2 gap-12 items-center relative z-10">
        
        {/* Text Content */}
        <div className="text-center md:text-left order-2 md:order-1 space-y-8">
          <h1 className="text-5xl md:text-7xl font-display text-indigo leading-tight">
            Discover the <br />
            <span className="font-serif italic text-gold">Soul</span> of Morocco
          </h1>
          <p className="text-lg md:text-xl text-indigo/80 font-light max-w-md mx-auto md:mx-0 leading-relaxed">
            Curated journeys for the discerning traveler. Unearth ancient secrets, 
            luxuriate in private riads, and traverse the dunes in unparalleled comfort.
          </p>
          <div className="flex flex-col md:flex-row gap-6 justify-center md:justify-start pt-4">
             <a href="#planner" className="px-8 py-4 bg-indigo text-cream font-display tracking-widest hover:bg-gold transition-colors duration-300">
               DESIGN YOUR JOURNEY
             </a>
             <a href="#experience" className="px-8 py-4 border border-indigo text-indigo font-display tracking-widest hover:bg-indigo hover:text-white transition-colors duration-300">
               EXPLORE COLLECTIONS
             </a>
          </div>
        </div>

        {/* Image Feature with Arch Mask */}
        <div className="order-1 md:order-2 flex justify-center relative">
          <div className="relative w-full max-w-md aspect-[3/4]">
             {/* Decorative Border behind */}
             <div className="absolute inset-0 border border-gold translate-x-4 translate-y-4 rounded-t-full z-0"></div>
             
             {/* Main Image Container */}
             <div className="absolute inset-0 rounded-t-full overflow-hidden shadow-2xl z-10 bg-indigo/10">
                {slides.map((slide, index) => (
                  <div 
                    key={index}
                    className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${index === currentSlide ? 'opacity-100' : 'opacity-0'}`}
                  >
                    <img 
                      src={slide.image} 
                      alt={slide.alt} 
                      className="w-full h-full object-cover transform hover:scale-105 transition-transform duration-[10000ms]"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-indigo/50 to-transparent mix-blend-multiply"></div>
                  </div>
                ))}
             </div>

             {/* Floating Badge */}
             <div className="absolute -bottom-6 -left-6 bg-cream p-4 shadow-xl border border-gold/30 z-20 max-w-[200px] transition-all duration-500">
                <p className="font-serif italic text-terracotta text-lg animate-fade-in key={currentSlide}">
                  "{slides[currentSlide].quote}"
                </p>
             </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 animate-bounce text-gold">
        <ArrowDown size={32} strokeWidth={1} />
      </div>
    </section>
  );
};