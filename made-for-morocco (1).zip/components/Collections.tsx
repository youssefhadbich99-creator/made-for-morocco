import React, { useState } from 'react';
import { ArrowRight, MapPin, Clock } from 'lucide-react';

const collections = [
  {
    id: 1,
    title: "Imperial Grandeur",
    subtitle: "Cities of Kings",
    description: "Journey through time in Fes and Marrakech, exploring ancient medinas, majestic palaces, and hidden gardens.",
    image: "https://images.unsplash.com/photo-1539020140153-e479b8c22e70?q=80&w=1600&auto=format&fit=crop",
    location: "Fes • Marrakech • Meknes",
    duration: "8 DAYS"
  },
  {
    id: 2,
    title: "Sahara Whispers",
    subtitle: "Infinite Silence",
    description: "Experience the profound stillness of the dunes with private luxury camps and star-gazing sessions.",
    image: "https://images.unsplash.com/photo-1512632500708-1b3e95039ec4?q=80&w=1600&auto=format&fit=crop",
    location: "Merzouga • Erg Chebbi • Skoura",
    duration: "5 DAYS"
  },
  {
    id: 3,
    title: "Atlantic Rhythms",
    subtitle: "Coastal Breezes",
    description: "Unwind where the desert meets the ocean, from the blue walls of Chefchaouen to the ramparts of Essaouira.",
    image: "https://images.unsplash.com/photo-1589793463308-65868f662914?q=80&w=1600&auto=format&fit=crop",
    location: "Essaouira • Oualidia • Tangier",
    duration: "10 DAYS"
  },
  {
    id: 4,
    title: "The Atlas Route",
    subtitle: "Kasbahs & Peaks",
    description: "Traverse the High Atlas Mountains, discovering ancient earthen fortresses and lush hidden valleys.",
    image: "https://images.unsplash.com/photo-1576189953936-24876b5c4793?q=80&w=1600&auto=format&fit=crop",
    location: "High Atlas • Ait Ben Haddou • Dades",
    duration: "7 DAYS"
  }
];

export const Collections: React.FC = () => {
  const [activeId, setActiveId] = useState(1);

  return (
    <section id="experience" className="py-24 bg-cream relative overflow-hidden">
      {/* Decorative background element */}
      <div className="absolute top-0 right-0 w-1/2 h-full bg-pattern-subtle opacity-10 pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-6">
        
        {/* Section Title */}
        <div className="text-center mb-20">
           <span className="text-terracotta font-display tracking-[0.3em] text-sm uppercase">Handcrafted Journeys</span>
           <h2 className="text-5xl md:text-6xl font-display text-indigo mt-3">Signature Collections</h2>
           <div className="w-24 h-[1px] bg-gold mx-auto mt-8"></div>
        </div>

        <div className="grid lg:grid-cols-2 gap-16 items-start">
          
          {/* Left: Content & Navigation */}
          <div className="order-2 lg:order-1 relative z-10 pt-8">
             
             {/* Interactive List */}
             <div className="space-y-8">
                {collections.map((item) => (
                  <div 
                    key={item.id}
                    className={`group cursor-pointer transition-all duration-500 pl-6 border-l-2 ${activeId === item.id ? 'border-gold' : 'border-indigo/10'}`}
                    onClick={() => setActiveId(item.id)}
                    onMouseEnter={() => setActiveId(item.id)}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <h3 className={`font-display text-2xl md:text-3xl transition-colors duration-300 ${activeId === item.id ? 'text-indigo' : 'text-indigo/40 group-hover:text-indigo/70'}`}>
                        {item.title}
                      </h3>
                      {activeId === item.id && <ArrowRight className="text-gold animate-pulse hidden lg:block" size={24} />}
                    </div>
                    
                    {/* Content Container */}
                    <div className={`overflow-hidden transition-all duration-500 ease-in-out ${activeId === item.id ? 'max-h-[600px] opacity-100 mt-4' : 'max-h-0 opacity-0'}`}>
                       
                       {/* Mobile Only Inline Image */}
                       <div className="lg:hidden mb-6 relative h-56 w-full rounded-sm overflow-hidden shadow-md border-4 border-white">
                          <img 
                            src={item.image} 
                            alt={item.title} 
                            className="w-full h-full object-cover"
                          />
                          <div className="absolute top-2 right-2 bg-cream/90 backdrop-blur-sm px-3 py-1 shadow-sm">
                             <span className="text-xs font-display tracking-widest text-indigo flex items-center gap-1">
                               <Clock size={10} /> {item.duration}
                             </span>
                          </div>
                       </div>

                       <p className="font-serif text-indigo/70 leading-relaxed max-w-lg mb-4 text-base md:text-lg">
                         {item.description}
                       </p>
                       <div className="flex items-center gap-2 text-xs font-bold tracking-widest text-terracotta uppercase">
                          <MapPin size={14} />
                          {item.location}
                       </div>
                    </div>
                  </div>
                ))}
             </div>

             {/* Moved Button */}
             <div className="mt-12 flex justify-start">
                 <a 
                   href="#planner" 
                   className="inline-flex items-center gap-4 px-8 py-4 bg-indigo text-gold font-display tracking-widest hover:bg-gold hover:text-indigo transition-all duration-500 shadow-xl text-sm border border-gold/20"
                 >
                   DESIGN YOUR OWN JOURNEY
                   <ArrowRight size={16} />
                 </a>
             </div>
          </div>

          {/* Right: Visual Display (Desktop Only) */}
          <div className="hidden lg:flex order-1 lg:order-2 justify-center items-center relative min-h-[500px]">
             
             {/* Image Frame Container - Fixed Size */}
             <div className="relative w-[380px] h-[480px]">
                 
                 {/* 1. Offset Gold Border (Background) */}
                 <div className="absolute inset-0 border border-gold translate-x-6 translate-y-6 z-0 rounded-sm"></div>
                 
                 {/* 2. Main Image Card (White border + Shadow) */}
                 <div className="absolute inset-0 bg-white p-3 shadow-2xl z-10 rounded-sm">
                    <div className="relative w-full h-full overflow-hidden bg-indigo/5">
                        {collections.map((item) => (
                           <div 
                             key={item.id}
                             className={`absolute inset-0 transition-opacity duration-700 ease-in-out ${activeId === item.id ? 'opacity-100' : 'opacity-0'}`}
                           >
                             <img 
                               src={item.image} 
                               alt={item.title}
                               className="w-full h-full object-cover"
                             />
                             {/* Subtle grain/overlay */}
                             <div className="absolute inset-0 bg-indigo/5 mix-blend-multiply"></div>
                             
                             {/* Duration Badge */}
                             <div className="absolute top-4 right-4 bg-cream/95 backdrop-blur-md px-4 py-2 shadow-lg border border-gold/20">
                                <span className="text-xs font-display tracking-[0.2em] text-indigo flex items-center gap-2">
                                   <Clock size={12} className="text-gold" /> {item.duration}
                                </span>
                             </div>
                           </div>
                        ))}
                    </div>
                 </div>

                 {/* 3. Floating Badge Intersecting Border */}
                 <div className="absolute -bottom-6 -left-8 z-20 bg-indigo text-cream px-8 py-4 shadow-xl">
                     <span className="font-serif italic text-xl tracking-wide">
                       {collections.find(c => c.id === activeId)?.subtitle}
                     </span>
                 </div>
             </div>
          </div>

        </div>
      </div>
    </section>
  );
};