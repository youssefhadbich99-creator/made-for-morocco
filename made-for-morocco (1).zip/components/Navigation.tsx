import React, { useState, useEffect } from 'react';
import { Logo } from './Logo';
import { Menu, X } from 'lucide-react';

export const Navigation: React.FC = () => {
  const [scrolled, setScrolled] = useState(false);
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Lock body scroll when menu is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  const navClasses = `fixed top-0 left-0 right-0 z-50 transition-all duration-500 ease-in-out border-b border-transparent ${
    scrolled ? 'bg-cream/95 backdrop-blur-md py-2 border-gold/20 shadow-sm' : 'bg-transparent py-6'
  }`;

  return (
    <nav className={navClasses}>
      <div className="max-w-7xl mx-auto px-6 relative flex items-center justify-between z-50">
        
        {/* Left Links (Desktop) */}
        <div className="hidden md:flex space-x-12 flex-1 justify-start">
          <a href="#experience" className="text-indigo hover:text-terracotta transition-colors font-serif italic text-lg">The Experience</a>
          <a href="#destinations" className="text-indigo hover:text-terracotta transition-colors font-serif italic text-lg">Destinations</a>
        </div>

        {/* Center Logo */}
        <div className="flex-shrink-0 mx-4 transform transition-transform duration-500 hover:scale-105 cursor-pointer" onClick={() => { setIsOpen(false); window.scrollTo(0,0); }}>
           <Logo dark={true} className={scrolled ? "scale-90" : "scale-100"} />
        </div>

        {/* Right Links (Desktop) */}
        <div className="hidden md:flex space-x-12 flex-1 justify-end items-center">
          <a href="#planner" className="text-indigo hover:text-terracotta transition-colors font-serif italic text-lg">Bespoke Planner</a>
          <button className="px-6 py-2 border border-indigo text-indigo hover:bg-indigo hover:text-gold transition-all duration-300 rounded-sm font-display text-sm tracking-widest">
            INQUIRE
          </button>
        </div>

        {/* Mobile Menu Button */}
        <button 
          className="md:hidden text-indigo p-2 focus:outline-none"
          onClick={() => setIsOpen(!isOpen)}
          aria-label={isOpen ? "Close menu" : "Open menu"}
        >
          {isOpen ? <X size={28} /> : <Menu size={28} />}
        </button>
      </div>

      {/* Mobile Menu Overlay */}
      {isOpen && (
        <div className="fixed inset-0 bg-cream z-40 flex flex-col items-center justify-center space-y-8 animate-fade-in md:hidden overscroll-contain">
          <a href="#experience" onClick={() => setIsOpen(false)} className="text-3xl font-serif text-indigo hover:text-gold transition-colors">The Experience</a>
          <a href="#destinations" onClick={() => setIsOpen(false)} className="text-3xl font-serif text-indigo hover:text-gold transition-colors">Destinations</a>
          <a href="#planner" onClick={() => setIsOpen(false)} className="text-3xl font-serif text-indigo hover:text-gold transition-colors">Bespoke Planner</a>
          <button className="mt-8 px-8 py-3 bg-indigo text-gold font-display text-lg shadow-lg">
            INQUIRE NOW
          </button>
        </div>
      )}
    </nav>
  );
};