import React from 'react';
import { Logo } from './Logo';
import { Instagram, Facebook, Mail } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-indigo text-cream pt-20 pb-10 border-t border-gold/20">
       <div className="max-w-7xl mx-auto px-6">
         <div className="flex flex-col items-center mb-16">
            <Logo dark={false} className="mb-8" />
            <p className="font-serif italic text-lg text-center max-w-lg text-cream/70">
              "We do not just show you Morocco. We invite you to become part of its story."
            </p>
         </div>

         <div className="grid grid-cols-1 md:grid-cols-3 gap-12 border-t border-white/10 pt-12">
            <div className="text-center md:text-left">
              <h4 className="font-display text-gold tracking-widest mb-6">CONTACT</h4>
              <p className="font-serif italic mb-2">hello@madeformorocco.com</p>
              <p className="font-serif italic">+212 615 931 039</p>
              <p className="font-sans text-xs mt-4 opacity-50">Marrakech, Morocco</p>
            </div>

            <div className="text-center">
               <h4 className="font-display text-gold tracking-widest mb-6">LEGAL</h4>
               <ul className="space-y-2 text-sm opacity-60">
                 <li><a href="#" className="hover:text-gold transition-colors">Privacy Policy</a></li>
                 <li><a href="#" className="hover:text-gold transition-colors">Terms & Conditions</a></li>
                 <li><a href="#" className="hover:text-gold transition-colors">License #99281</a></li>
               </ul>
            </div>

            <div className="text-center md:text-right">
              <h4 className="font-display text-gold tracking-widest mb-6">FOLLOW US</h4>
              <div className="flex justify-center md:justify-end gap-6">
                 <a href="#" className="hover:text-gold transition-colors"><Instagram strokeWidth={1.5} /></a>
                 <a href="#" className="hover:text-gold transition-colors"><Facebook strokeWidth={1.5} /></a>
                 <a href="#" className="hover:text-gold transition-colors"><Mail strokeWidth={1.5} /></a>
              </div>
            </div>
         </div>
         
         <div className="text-center mt-16 text-xs opacity-30 font-display">
           © {new Date().getFullYear()} MADE FOR MOROCCO. ALL RIGHTS RESERVED.
         </div>
       </div>
    </footer>
  );
};