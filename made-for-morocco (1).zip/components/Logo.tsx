import React from 'react';

export const Logo: React.FC<{ className?: string, dark?: boolean }> = ({ className = "", dark = false }) => {
  return (
    <div className={`flex items-center justify-center ${className}`}>
      <img 
        src={dark 
          ? "https://i.postimg.cc/TYP0HK43/Untitled-design-(1).png" 
          : "https://i.postimg.cc/Gh9PxZ4H/Untitled-design-(2)-Copy.png"
        }
        alt="Made For Morocco" 
        className="h-20 md:h-24 w-auto object-contain transition-all duration-300"
      />
    </div>
  );
};