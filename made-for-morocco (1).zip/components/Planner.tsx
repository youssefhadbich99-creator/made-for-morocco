import React, { useState } from 'react';
import { generateBespokeItinerary } from '../services/geminiService';
import { GeneratedItinerary, ItineraryRequest } from '../types';
import { Sparkles, Loader2, Calendar, Users, Heart } from 'lucide-react';

export const Planner: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<GeneratedItinerary | null>(null);
  
  const [formData, setFormData] = useState<ItineraryRequest>({
    duration: 7,
    travelers: 2,
    interests: [],
    style: 'luxury'
  });

  const availableInterests = ['History', 'Food & Wine', 'Architecture', 'Adventure', 'Shopping', 'Wellness'];

  const toggleInterest = (interest: string) => {
    setFormData(prev => ({
      ...prev,
      interests: prev.interests.includes(interest) 
        ? prev.interests.filter(i => i !== interest)
        : [...prev.interests, interest]
    }));
  };

  const handleGenerate = async () => {
    setLoading(true);
    setResult(null);
    try {
      const itinerary = await generateBespokeItinerary(formData);
      setResult(itinerary);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <section id="planner" className="py-24 bg-indigo relative text-cream">
       <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-5"></div>
       
       <div className="max-w-6xl mx-auto px-6 relative z-10">
         <div className="text-center mb-16 space-y-4">
           <h2 className="text-4xl md:text-5xl font-display text-gold">The AI Concierge</h2>
           <p className="font-serif italic text-xl text-cream/80">Draft your preliminary bespoke journey in seconds.</p>
         </div>

         <div className="grid md:grid-cols-2 gap-16">
            
            {/* Form Side */}
            <div className="bg-white/5 backdrop-blur-sm p-8 border border-white/10 rounded-sm">
               <div className="space-y-8">
                  {/* Duration Slider */}
                  <div>
                    <label className="flex items-center gap-2 font-display tracking-widest text-sm mb-4">
                      <Calendar className="text-gold" size={18} /> DURATION: {formData.duration} DAYS
                    </label>
                    <input 
                      type="range" 
                      min="3" 
                      max="21" 
                      value={formData.duration} 
                      onChange={(e) => setFormData({...formData, duration: parseInt(e.target.value)})}
                      className="w-full accent-gold h-1 bg-white/20 rounded-lg appearance-none cursor-pointer"
                    />
                  </div>

                  {/* Travelers */}
                  <div>
                    <label className="flex items-center gap-2 font-display tracking-widest text-sm mb-4">
                       <Users className="text-gold" size={18} /> TRAVELERS: {formData.travelers}
                    </label>
                     <div className="flex gap-4">
                        {[1, 2, 4, 6, '8+'].map((num) => (
                           <button 
                             key={num}
                             onClick={() => setFormData({...formData, travelers: typeof num === 'number' ? num : 10})}
                             className={`w-10 h-10 border ${formData.travelers === (typeof num === 'number' ? num : 10) ? 'bg-gold border-gold text-indigo' : 'border-white/20 hover:border-gold'} transition-all`}
                           >
                             {num}
                           </button>
                        ))}
                     </div>
                  </div>

                  {/* Style */}
                  <div>
                    <label className="flex items-center gap-2 font-display tracking-widest text-sm mb-4">
                       <Heart className="text-gold" size={18} /> STYLE
                    </label>
                    <select 
                      className="w-full bg-transparent border-b border-white/20 py-2 focus:outline-none focus:border-gold text-cream"
                      value={formData.style}
                      onChange={(e) => setFormData({...formData, style: e.target.value as any})}
                    >
                      <option value="luxury" className="text-indigo">Ultra Luxury</option>
                      <option value="cultural" className="text-indigo">Cultural Immersion</option>
                      <option value="adventure" className="text-indigo">Refined Adventure</option>
                      <option value="relaxing" className="text-indigo">Wellness & Relaxation</option>
                    </select>
                  </div>

                  {/* Interests */}
                  <div>
                     <label className="font-display tracking-widest text-sm mb-4 block">INTERESTS</label>
                     <div className="flex flex-wrap gap-3">
                       {availableInterests.map(interest => (
                         <button
                           key={interest}
                           onClick={() => toggleInterest(interest)}
                           className={`px-4 py-1 text-sm border ${formData.interests.includes(interest) ? 'bg-terracotta border-terracotta text-white' : 'border-white/20 text-white/60 hover:border-white/60'} rounded-full transition-all`}
                         >
                           {interest}
                         </button>
                       ))}
                     </div>
                  </div>

                  <button 
                    onClick={handleGenerate}
                    disabled={loading}
                    className="w-full py-4 bg-gold text-indigo font-display tracking-widest hover:bg-white transition-colors flex items-center justify-center gap-2 mt-8 disabled:opacity-50"
                  >
                    {loading ? <Loader2 className="animate-spin" /> : <Sparkles size={18} />}
                    {loading ? 'WEAVING MAGIC...' : 'GENERATE MY ITINERARY'}
                  </button>
               </div>
            </div>

            {/* Result Side */}
            <div className="relative min-h-[400px]">
               {loading && (
                 <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-8">
                   <div className="w-16 h-16 border-t-2 border-b-2 border-gold rounded-full animate-spin mb-4"></div>
                   <p className="font-serif italic text-xl">Consulting the stars and maps...</p>
                 </div>
               )}

               {!loading && !result && (
                 <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-8 border-2 border-dashed border-white/10">
                   <p className="font-serif italic text-2xl text-white/30">Your journey awaits creation.</p>
                 </div>
               )}

               {result && !loading && (
                 <div className="bg-cream text-indigo p-8 h-full shadow-2xl relative animate-fade-in-up">
                    <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-gold via-terracotta to-indigo"></div>
                    <h3 className="text-3xl font-serif text-terracotta mb-2">{result.title}</h3>
                    <p className="text-sm italic text-indigo/60 mb-6 border-b border-indigo/10 pb-4">{result.summary}</p>
                    
                    <div className="space-y-6 max-h-[500px] overflow-y-auto pr-2 custom-scrollbar">
                      {result.days.map((day) => (
                        <div key={day.day} className="flex gap-4 group">
                          <div className="flex-shrink-0 w-12 h-12 bg-indigo text-gold flex items-center justify-center font-display rounded-t-full rounded-bl-full">
                            {day.day}
                          </div>
                          <div>
                            <h4 className="font-bold font-serif text-lg mb-1">{day.title}</h4>
                            <ul className="text-sm space-y-1 text-indigo/80">
                              {day.activities.map((act, idx) => (
                                <li key={idx} className="flex items-start gap-2">
                                  <span className="text-gold mt-1.5">•</span> {act}
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      ))}
                    </div>
                    
                    <button className="mt-8 w-full py-3 border border-indigo text-indigo hover:bg-indigo hover:text-white transition-colors font-display text-sm tracking-widest">
                      REQUEST FULL PROPOSAL
                    </button>
                 </div>
               )}
            </div>
         </div>
       </div>
    </section>
  );
};
