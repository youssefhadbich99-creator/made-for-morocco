import React from 'react';
import { ArrowUpRight } from 'lucide-react';

const destinations = [
  {
    id: "01",
    name: "Marrakech",
    subtitle: "The Red City",
    desc: "A sensory labyrinth of ancient souks, secret gardens, and palatial riots of color.",
    img: "https://images.unsplash.com/photo-1597211684694-8f63f48d65d1?q=80&w=800&auto=format&fit=crop",
  },
  {
    id: "02",
    name: "Merzouga",
    subtitle: "The Sahara",
    desc: "Golden dunes stretching to infinity under starlit skies and silence.",
    img: "https://images.unsplash.com/photo-1512632500708-1b3e95039ec4?q=80&w=800&auto=format&fit=crop",
  },
  {
    id: "03",
    name: "Chefchaouen",
    subtitle: "The Blue Pearl",
    desc: "A mountain sanctuary painted in calming shades of infinite azure.",
    img: "https://images.unsplash.com/photo-1534445653457-3f33663b6526?q=80&w=800&auto=format&fit=crop",
  },
  {
    id: "04",
    name: "Fes",
    subtitle: "Imperial Soul",
    desc: "The world's largest car-free urban area, preserving a medieval way of life.",
    img: "https://images.unsplash.com/photo-1548013146-72479768bada?q=80&w=800&auto=format&fit=crop",
  }
];

export const Destinations: React.FC = () => {
  return (
    <section id="destinations" className="py-12 bg-cream">
      <div className="max-w-7xl mx-auto px-6 mb-8">
        <div className="flex flex-col md:flex-row justify-between items-end gap-4">
          <div>
             <span className="text-terracotta font-display tracking-[0.3em] text-xs uppercase">The Kingdom</span>
             <h2 className="text-3xl md:text-4xl font-display text-indigo mt-2">Curated Destinations</h2>
          </div>
          <p className="font-serif italic text-indigo/60 text-right max-w-sm text-xs md:text-sm">
            "A mosaic of landscapes, each telling a different story of time and beauty."
          </p>
        </div>
      </div>

      {/* Accordion Container - Super Compact Height */}
      <div className="w-full h-auto md:h-[450px] flex flex-col md:flex-row bg-indigo border-y border-gold/10">
         {destinations.map((dest) => (
           <div 
             key={dest.id}
             className="group relative flex-1 hover:flex-[4] transition-all duration-700 ease-[cubic-bezier(0.25,0.1,0.25,1)] cursor-pointer overflow-hidden min-h-[160px] md:min-h-auto border-b md:border-b-0 md:border-r border-white/10 last:border-0"
           >
              {/* Image with subtle zoom on hover */}
              <div className="absolute inset-0 w-full h-full">
                 <div className="absolute inset-0 bg-indigo/30 group-hover:bg-transparent z-10 transition-colors duration-500"></div>
                 <img 
                    src={dest.img} 
                    alt={dest.name} 
                    className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105 filter grayscale-[30%] group-hover:grayscale-0"
                 />
                 {/* Dark Gradient Overlay for text readability */}
                 <div className="absolute inset-0 bg-gradient-to-t from-indigo/95 via-indigo/30 to-transparent opacity-90 md:opacity-100"></div>
              </div>

              {/* Desktop Vertical Title (Collapsed State) */}
              <div className="hidden md:flex absolute inset-0 items-center justify-center z-20 pointer-events-none transition-opacity duration-300 group-hover:opacity-0 delay-0 group-hover:delay-0 opacity-100">
                 <h3 className="text-2xl font-display text-white/60 tracking-[0.2em] -rotate-90 whitespace-nowrap uppercase">
                    {dest.name}
                 </h3>
              </div>

              {/* Content (Expanded State) */}
              <div className="absolute bottom-0 left-0 w-full p-5 md:p-8 z-30 flex flex-col justify-end h-full pointer-events-none group-hover:pointer-events-auto">
                 <div className="transform translate-y-0 md:translate-y-4 md:group-hover:translate-y-0 transition-transform duration-500 delay-100">
                    
                    {/* ID & Subtitle */}
                    <div className="flex items-center gap-2 mb-1 opacity-100 md:opacity-0 md:group-hover:opacity-100 transition-opacity duration-500 delay-200">
                       <span className="text-gold font-display text-xs">{dest.id}</span>
                       <div className="h-[1px] w-6 bg-gold/50"></div>
                       <span className="text-white/80 font-serif italic tracking-wider text-xs">{dest.subtitle}</span>
                    </div>

                    {/* Main Title */}
                    <h3 className="text-2xl md:text-4xl font-display text-white mb-2 leading-tight">
                       {dest.name}
                    </h3>

                    {/* Description - Masked Reveal */}
                    <div className="grid grid-rows-[1fr] md:grid-rows-[0fr] md:group-hover:grid-rows-[1fr] transition-all duration-700 ease-in-out">
                       <div className="overflow-hidden">
                          <p className="text-white/80 font-sans text-xs md:text-sm leading-relaxed max-w-md mb-3 opacity-100 md:opacity-0 md:group-hover:opacity-100 transition-opacity duration-700 delay-300">
                             {dest.desc}
                          </p>
                          
                          <button className="inline-flex items-center gap-2 text-gold font-display tracking-widest text-[10px] md:text-xs hover:text-white transition-colors uppercase group/btn opacity-100 md:opacity-0 md:group-hover:opacity-100 transition-opacity duration-700 delay-500">
                             Explore {dest.name} <ArrowUpRight size={12} className="group-hover/btn:translate-x-1 group-hover/btn:-translate-y-1 transition-transform" />
                          </button>
                       </div>
                    </div>

                 </div>
              </div>
           </div>
         ))}
      </div>
    </section>
  );
};