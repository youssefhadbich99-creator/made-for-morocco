import { GoogleGenAI, Type } from "@google/genai";
import { ItineraryRequest, GeneratedItinerary } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateBespokeItinerary = async (req: ItineraryRequest): Promise<GeneratedItinerary> => {
  const model = "gemini-2.5-flash";
  
  const prompt = `
    Create a bespoke, exclusive travel itinerary for Morocco.
    Duration: ${req.duration} days.
    Travelers: ${req.travelers}.
    Travel Style: ${req.style}.
    Interests: ${req.interests.join(", ")}.
    
    The tone should be sophisticated, magical, and luxurious. Focus on unique experiences (e.g., private tea in the Sahara, after-hours museum tours).
  `;

  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING, description: "A creative, evocative title for the trip" },
            summary: { type: Type.STRING, description: "A 2-sentence summary of the journey's essence" },
            days: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  day: { type: Type.INTEGER },
                  title: { type: Type.STRING, description: "Theme of the day (e.g., 'The Blue Pearl')" },
                  activities: { 
                    type: Type.ARRAY, 
                    items: { type: Type.STRING },
                    description: "List of 2-3 exclusive activities"
                  }
                },
                required: ["day", "title", "activities"]
              }
            }
          },
          required: ["title", "summary", "days"]
        }
      }
    });

    if (response.text) {
      return JSON.parse(response.text) as GeneratedItinerary;
    }
    throw new Error("No content generated");
  } catch (error) {
    console.error("Gemini API Error:", error);
    // Fallback mock data in case of API failure for demo purposes
    return {
      title: "The Golden Route (Sample)",
      summary: "An error occurred generating your custom plan, but here is a sample of what we offer.",
      days: [
        { day: 1, title: "Arrival in Marrakech", activities: ["Private transfer to Riad", "Dinner at Le Jardin Secret"] },
        { day: 2, title: "Secrets of the Medina", activities: ["Exclusive guided souk tour", "Perfume making workshop"] }
      ]
    };
  }
};
